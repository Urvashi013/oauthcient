package in.nic.OauthClient;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.HttpHeaders;

import org.apache.http.NameValuePair;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONObject;

import com.mongodb.DBObject;
import com.mongodb.util.JSON;

@SuppressWarnings("deprecation")
public class GetAccessTokenServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;
	private static final Logger log = LogManager.getLogger(GetAccessTokenServlet.class.getName());

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		System.out.println("Test Called!!");

		getAccessToken(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		System.out.println("Test Called!!11");
		getAccessToken(request, response);
	}

	public void getAccessToken(@Context HttpServletRequest request, @Context HttpServletResponse response)
			throws IOException {

		System.out.println("getAccessToken called");
		ResourceBundle rbOauth = ResourceBundle.getBundle("oauth");

		String client_id = rbOauth.getString("client_id");
		String redirect_uri = rbOauth.getString("redirect_uri");
		String code = request.getParameter("code");
		String client_secret = request.getParameter("client_secret");
		String code_verifier = rbOauth.getString("code_verifier");
		String grant_type = rbOauth.getString("grant_type");

		System.out.println("getAccessToken called");

		if (!redirect_uri.equals(rbOauth.getString("redirect_uri"))) {

			log.error("Redirect URL did not match : " + redirect_uri);

		}

		String accessTokenURL = "client_id=" + client_id + "&client_secret=" + client_secret + "&redirect_uri="
				+ redirect_uri + "&code=" + code + "&grant_type=" + grant_type + "&code_verifier=" + code_verifier;

		System.out.println("Access Token Client URL: " + accessTokenURL);

		JSONObject json = new JSONObject();
		json.put("client_id", client_id);
		json.put("redirect_uri", redirect_uri);
		json.put("code", code);
		json.put("client_secret", client_secret);
		json.put("grant_type", grant_type);
		json.put("code_verifier", code_verifier);

		System.out.println("Response : " + json.toString());

		// add request parameter, form parameters
		List<NameValuePair> urlParameters = new ArrayList<>();
		urlParameters.add(new BasicNameValuePair("client_id", client_id));
		urlParameters.add(new BasicNameValuePair("client_secret", client_secret));
		urlParameters.add(new BasicNameValuePair("code", code));
		urlParameters.add(new BasicNameValuePair("redirect_uri", redirect_uri));
		urlParameters.add(new BasicNameValuePair("code_verifier", code_verifier));
		urlParameters.add(new BasicNameValuePair("grant_type", grant_type));

		HttpPost post = new HttpPost(rbOauth.getString("PARICHAY_AUTH_TOKEN_API"));

		post.setEntity(new UrlEncodedFormEntity(urlParameters));

		Object tokenJson = "";

		try (CloseableHttpClient httpClient = HttpClientBuilder.create().build();
				CloseableHttpResponse postResponse = httpClient.execute(post)) {

			tokenJson = JSON.parse(EntityUtils.toString(postResponse.getEntity()));

		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Consent Denied");

			return;
		}
		System.out.println("Response from Parichay : " + tokenJson.toString());

		getUserdetails(request, response, tokenJson.toString());
	}

	public void getUserdetails(@Context HttpServletRequest request, @Context HttpServletResponse response,
			String tokenJson) throws IOException {

		System.out.println("getUserdetails called");

		JSONObject json = new JSONObject(tokenJson);
		Map<String, String> childMap = new HashMap<>();

		System.out.println("Access_token : " + json.getString("access_token"));
		HttpGet get = new HttpGet(ResourceBundle.getBundle("oauth").getString("PARICHAY_TOKEN_URL"));

		get.setHeader("Authorization", json.getString("access_token"));

//		HttpGet get = new HttpGet(
//				ResourceBundle.getBundle("app").getString("PARICHAY_TOKEN_URL")  + json.getString("access_token"));

		Object userJsonObj = "";

		try (CloseableHttpClient httpClient = HttpClientBuilder.create().build();
				CloseableHttpResponse postResponse = httpClient.execute(get);) {

			userJsonObj = JSON.parse(EntityUtils.toString(postResponse.getEntity()));

			// FETCH RESPECTIVE COOKIES FROM BROWSER COOKIE STORE

			System.out.println("User details JSON Object: " + userJsonObj);
			DBObject userJson = (DBObject) userJsonObj;
			System.out.println("User details JSON: " + userJson);

			PrintWriter pw = response.getWriter();
			try {
				pw.print("<html> <marquee direction = 'left'><strong>WELCOME TO THE WORLD OF OAUTH<strong></marquee>");
				pw.print("<div text-align: center;><br>Name: " + userJson.get("FirstName") + " "
						+ userJson.get("LastName"));
			} catch (Exception e) {
				pw.print("Name: " + userJson.get("FirstName"));
			}
			pw.print("<br>Mobile Number: " + userJson.get("MobileNo") + "</div>");
			
			
			pw.print("<br>LoginId: " + userJson.get("loginId") + "</div>");
			pw.print("<br>ParichayId: " + userJson.get("parichayId") + "</div>");
			pw.print("<br>Employee Code : " + userJson.get("employeeCode") + "</div>");
			// pw.print("<br>Login Id: " + userJson.get("loginId")+"</html>");

			return;

		} catch (Exception e) {

			System.out.println("Some error occurred !!!");
			e.printStackTrace();
		}
		// return userJsonObj.toString();
	}

}
